﻿How to install dll
Framework 4.6 and up
Set IIS Application pool : Enable 32 bit application = true
Register dll 
	Take note the location of the dll
	C:\Windows\Microsoft.NET\Framework\v4.0.xxxx\RegAsm.exe -tlb -codebase FmBoComEncrypt.dll


//Decrypt once is global.asa file, otherwise the 
<script language="vbscript" runat="server">

sub Application_OnStart
	Set customEnc = CreateObject("FmBoComEncrypt.Encryption")
	Application("dbPass") = customEnc.Decrypt("encryptedtext")
	Set customEnc = Nothing
end sub

</script>

//use in other part of the code 
Response.write Application("dbPass")

//code for setting up the password
Set customEnc = CreateObject("FmBoComEncrypt.Encryption")
Response.Write customEnc.Encrypt("Hello")
Set customEnc = Nothing
