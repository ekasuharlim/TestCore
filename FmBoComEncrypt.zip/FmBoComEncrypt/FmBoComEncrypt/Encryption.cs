﻿using System.Runtime.InteropServices;

namespace FmBoComEncrypt
{
    [Guid("EAA4976A-45C3-4BC5-BC0B-E474F4C3C83F")]
    public interface IEncryption 
    {
        string Encrypt(string text);
        string Decrypt(string text);
        string Version();

    }

    [Guid("0D53A3E8-E51A-49C7-944E-E72A2064F938"),
        ClassInterface(ClassInterfaceType.None),
        ComSourceInterfaces(typeof(IEncryption))]
    public class Encryption : IEncryption
    {
        private EncryptionMethod method;
        private string salt = "FmBoAgrEnc";

        public Encryption() 
        {
            method = new EncryptionMethod();
        }
        public string Decrypt(string text)
        {
            return method.Decrypt(text,salt);
        }

        public string Encrypt(string text)
        {
            return method.Encrypt(text,salt);
        }

        public string Version() 
        {
            return method.Version();
        }
    }
}
